<?php $this->load->view('header-login.php'); ?>

<body>

<?php $this->load->view($content_view); ?>


<?php $this->load->view('footer-login.php'); ?>
